import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Hugehard Doors 0.11 - Windows93 Parody OS',
  description: 'A humorous retro operating system with draggable shortcuts, EXEsafe.com, and questionable virus simulations.',
  openGraph: {
    title: 'Hugehard Doors 0.11',
    description: 'A humorous retro operating system with draggable shortcuts, EXEsafe.com, and questionable virus simulations.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hugehard Doors 0.11',
    description: 'A humorous retro operating system with draggable shortcuts, EXEsafe.com, and questionable virus simulations.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
